﻿**Визуализация датасета**

[Price of flats in Moscow](https://www.kaggle.com/datasets/hugoncosta/price-of-flats-in-moscow)

На Дашборд [Московские квартиры](https://datalens.yandex/lquuovfzx1kgc)
