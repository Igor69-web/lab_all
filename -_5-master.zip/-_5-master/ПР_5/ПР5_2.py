from geometry import *
a = planimetry.Rectangle(3,4)
b = stereometry.Ball(5)
print(a.square())