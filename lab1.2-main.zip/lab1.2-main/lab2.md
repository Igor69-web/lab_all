﻿**Визуализация датасета**

Ссылка на коллаб [Collab](https://colab.research.google.com/drive/1E3CVvilTofpmeJekU6eFA5ghQ7hovcKW?usp=sharing)

На Дашборд [NPS_date](https://datalens.yandex.ru/sz9vu64uzo3uj-nps-date-num)

На Google Dashboard[NPS](https://datastudio.google.com/reporting/92bf9ffa-4da4-48ef-b55a-c6fc597dd82e)